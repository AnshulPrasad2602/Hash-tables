/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashtables;

/**
 *
 * @author ANSHUL
 */
public class Hashtables {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        Employee e1 = new Employee("Anshul", "Prasad", 11);
        Employee e2 = new Employee("Ria", "Singh", 56);
        Employee e3 = new Employee("Drishti", "S", 26);
        Employee e4 = new Employee("Gautam", "B", 27);
        Employee e5 = new Employee("Aryan", "Gupta", 16);
        
        SimpleHashtable ht = new SimpleHashtable();
        
        ht.put(e1.getLastName(), e1);
        ht.put(e2.getLastName(), e2);
        ht.put(e3.getLastName(), e3);
        ht.put(e4.getLastName(), e4);
        ht.put(e5.getLastName(), e5);
        
        System.out.println("---------------hashtable ->");
        ht.printHashtable();
        
        System.out.println("\nRetrive -> " + ht.get(e1.getLastName()));
        
        System.out.println("\nRetrive -> " + ht.get(e2.getLastName()));
        
        System.out.println("\nRetrive -> " + ht.get(e5.getLastName()));
        
        System.out.println("\nRemove -> " + ht.remove(e3.getLastName()));
        System.out.println("\nRemove -> " + ht.remove(e5.getLastName()));
        
        System.out.println("---------------hashtable ->");
        ht.printHashtable();
    }
    
}
