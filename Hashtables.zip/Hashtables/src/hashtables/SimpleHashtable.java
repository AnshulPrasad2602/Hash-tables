/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashtables;

/**
 *
 * @author ANSHUL
 */
public class SimpleHashtable 
{
    private StoredEmployee[] hashtable;

    public SimpleHashtable() 
    {
        hashtable = new StoredEmployee[10];
    }
    
    private int hashKey(String key)
    {
        return key.length() % hashtable.length;
    }
    
    public void put(String key, Employee emp)
    {
        int hashedKey = this.hashKey(key);
        
        if (this.occupied(hashedKey))   //to handle collision
        {
            int stopIndex = hashedKey;
            
            if (hashedKey == hashtable.length - 1)
            {
                hashedKey = 0;
            }
            else
            {
                hashedKey++;
            }
            
            while (occupied(hashedKey) && hashedKey != stopIndex)
            {
                hashedKey = (hashedKey + 1) % hashtable.length;
            }
        }
        
        if (this.occupied(hashedKey))   
        {
            System.out.println("Employee already exists at " + hashedKey);
        }
        else
        {
            hashtable[hashedKey] = new StoredEmployee(key, emp);
        }
    }
    
    public Employee get(String key)
    {
        int hashedKey = findKey(key);
        
        if (hashedKey == -1)
        {
            return null;
        }
        
        return hashtable[hashedKey].emp;
    }
    
    public Employee remove(String key)
    {
        int hashedKey = findKey(key);
        
        if (hashedKey == -1)
        {
            return null;
        }
        
        Employee emp = hashtable[hashedKey].emp;
        hashtable[hashedKey] = null;
        
        //rehashing
        StoredEmployee[] oldHashtable = hashtable;
        hashtable = new StoredEmployee[oldHashtable.length];
        
        for (int i = 0; i < oldHashtable.length; i++)
        {
            if (oldHashtable[i] != null)
            {
                put(oldHashtable[i].key, oldHashtable[i].emp);
            }
        }
        
        return emp;
    }
    
    private int findKey (String key)
    {
        int hashedKey = this.hashKey(key);
        
        if (occupied(hashedKey) && hashtable[hashedKey].key.equals(key))
        {
            return hashedKey;
        }
        
        
        int stopIndex = hashedKey;
            
        if (hashedKey == hashtable.length - 1)
        {
            hashedKey = 0;
        }
        else
        {
            hashedKey++;
        }
            
        while (occupied(hashedKey) && hashedKey != stopIndex && !hashtable[hashedKey].key.equals(key))
        {
            hashedKey = (hashedKey + 1) % hashtable.length;
        }
        
        if (occupied(hashedKey) && hashtable[hashedKey].key.equals(key))
        {
            return hashedKey;
        }
        else
        {
            return -1;
        }
    }
    
    public void printHashtable()
    {
        for (int i = 0; i < hashtable.length; i++)
        {
            if (hashtable[i] == null)
            {
                System.out.println("empty");
            }
            else
            {
                System.out.println("Position " + i + " : " + hashtable[i].emp);
            }
            
        }
    }
    
    
    private boolean occupied(int index)
    {
        return hashtable[index] != null;
    }
    
}
