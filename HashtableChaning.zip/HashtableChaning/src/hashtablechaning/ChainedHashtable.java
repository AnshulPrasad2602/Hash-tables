/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashtablechaning;

import java.util.LinkedList;
import java.util.ListIterator;

/**
 *
 * @author ANSHUL
 */
public class ChainedHashtable 
{
    private LinkedList <StoredEmployee>[] hashtable;

    public ChainedHashtable() 
    {
        hashtable = new LinkedList[10];
        for (int i = 0; i < hashtable.length; i++)
        {
            hashtable[i] = new LinkedList <StoredEmployee>();
        }
    }
    
    public void put(String key, Employee emp)
    {
        int hashedKey = this.hashKey(key);
        
        hashtable[hashedKey].add(new StoredEmployee (key, emp));
    }
    
    public Employee get(String key)
    {
        int hashedKey = this.hashKey(key);
        
        ListIterator<StoredEmployee> itr = hashtable[hashedKey].listIterator();
        StoredEmployee employee = null;
        while (itr.hasNext())
        {
            employee = itr.next();
            if (employee.key.equals(key))
            {
                return employee.emp;
            }
        }
        
        return null;
    }
    
    public Employee remove(String key)
    {
        int hashedKey = this.hashKey(key);
        
        ListIterator<StoredEmployee> itr = hashtable[hashedKey].listIterator();
        StoredEmployee employee = null;
        int index = -1;
        while (itr.hasNext())
        {
            employee = itr.next();
            index++;
            if (employee.key.equals(key))
            {
                break;
            }
        }
        
        if (employee == null || !employee.key.equals(key))
        {
            return null;
        }
        else
        {
            hashtable[hashedKey].remove(index);     //or remove(employee) but it will iterate again in the backend so to avoid that remove(index) is used
            return employee.emp;
        }
    }
    
    private int hashKey(String key) //hashing function
    {
        //return key.length() % hashtable.length;
        
        return Math.abs(key.hashCode() % hashtable.length);
    }
    
    public void printHashtable()
    {
        for (int i = 0; i < hashtable.length; i++)
        {
            if (hashtable[i].isEmpty())
            {
                System.out.println("Position " + i + " : empty");
            }
            else
            {
                System.out.println("Position " + i + " : ");
                ListIterator<StoredEmployee> itr = hashtable[i].listIterator();
                while (itr.hasNext())
                {
                    StoredEmployee employee = itr.next();
                    System.out.println("" + employee.emp);
                }
                System.out.println("null");
            }
        }
    }
    
    
}
