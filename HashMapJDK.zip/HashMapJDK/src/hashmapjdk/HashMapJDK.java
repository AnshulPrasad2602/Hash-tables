/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hashmapjdk;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 *
 * @author ANSHUL
 */
public class HashMapJDK {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
         Employee e1 = new Employee("Anshul", "Prasad", 11);
        Employee e2 = new Employee("Ria", "Singh", 56);
        Employee e3 = new Employee("Drishti", "S", 26);
        Employee e4 = new Employee("Gautam", "B", 27);
        Employee e5 = new Employee("Aryan", "Gupta", 16);
        
        Map<String, Employee> ht = new HashMap<String, Employee>();
        
        ht.put(e1.getLastName(), e1);
        ht.put(e2.getLastName(), e2);
        ht.putIfAbsent(e3.getLastName(), e3);
        ht.put(e4.getLastName(), e4);
        ht.put(e5.getLastName(), e5);
        
        System.out.println("---------------hashtable ->");
//        Iterator<Employee> itr = ht.values().iterator();
//        while(itr.hasNext())
//        {
//            System.out.println("" + itr.next());
//        }

        ht.forEach((k, v) -> System.out.println("Key = " + k + ", Employee = " + v));
        
        System.out.println("" + ht.containsKey(e1.getLastName()));  //faster because key is given finding hashed value will be simpler 
        System.out.println("" + ht.containsValue(e4));  //need to traverse
        
        System.out.println("\nRetrive -> " + ht.get(e1.getLastName()));
        
        System.out.println("\nRetrive -> " + ht.get(e2.getLastName()));
        
        System.out.println("\nRetrive -> " + ht.get(e5.getLastName())); 
        
        System.out.println("\nRemove -> " + ht.remove(e3.getLastName()));
        System.out.println("\nRemove -> " + ht.remove(e5.getLastName()));
        
        ht.forEach((k, v) -> System.out.println("Key = " + k + ", Employee = " + v));
        
    }
    
}
